"""
Parser y Analizador de Rutas GPX
Procesa tracks GPS, calcula distancias acumuladas mediante la fórmula de Haversine,
suaviza ruido de altitud GPS y computa la pendiente del terreno en cada metro.
"""

import math
import gpxpy

class GpxRouteParser:
    def __init__(self):
        self.points = []
        self.total_distance_km = 0.0
        self.total_elevation_gain_m = 0.0
        self.max_slope_pct = 0.0
        self.is_loaded = False

    @staticmethod
    def haversine_km(lat1, lon1, lat2, lon2):
        """Calcula distancia ortodrómica en kilómetros entre dos coordenadas GPS."""
        r = 6371.0  # Radio terrestre en km
        d_lat = math.radians(lat2 - lat1)
        d_lon = math.radians(lon2 - lon1)
        a = (math.sin(d_lat / 2.0) ** 2 +
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
             math.sin(d_lon / 2.0) ** 2)
        c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
        return r * c

    def load_file(self, gpx_file_path):
        """Lee un archivo .gpx y construye la tabla de búsqueda distancia -> pendiente."""
        try:
            with open(gpx_file_path, "r", encoding="utf-8") as f:
                gpx = gpxpy.parse(f)

            raw_pts = []
            for track in gpx.tracks:
                for segment in track.segments:
                    for pt in segment.points:
                        raw_pts.append({
                            "lat": pt.latitude,
                            "lon": pt.longitude,
                            "elevation": pt.elevation or 0.0
                        })

            if not raw_pts:
                return False, "El archivo GPX no contiene puntos de track (<trkpt>)."

            # Calcular distancias acumuladas y pendientes suavizadas
            self.points = []
            cum_dist = 0.0
            total_ascent = 0.0
            max_slope = 0.0

            for i in range(len(raw_pts)):
                if i > 0:
                    d = self.haversine_km(
                        raw_pts[i-1]["lat"], raw_pts[i-1]["lon"],
                        raw_pts[i]["lat"], raw_pts[i]["lon"]
                    )
                    cum_dist += d
                    d_ele = raw_pts[i]["elevation"] - raw_pts[i-1]["elevation"]
                    if d_ele > 0:
                        total_ascent += d_ele

                # Ventana de suavizado para calcular pendiente
                win = min(3, min(i, len(raw_pts) - 1 - i))
                slope = 0.0
                if win > 0:
                    p_prev = raw_pts[i - win]
                    p_next = raw_pts[i + win]
                    d_win_km = self.haversine_km(p_prev["lat"], p_prev["lon"], p_next["lat"], p_next["lon"])
                    if d_win_km > 0.005:  # al menos 5 metros
                        d_ele_m = p_next["elevation"] - p_prev["elevation"]
                        slope = (d_ele_m / (d_win_km * 1000.0)) * 100.0
                        slope = max(-25.0, min(25.0, slope))  # Recortar picos aberrantes

                if slope > max_slope:
                    max_slope = slope

                self.points.append({
                    "distance_km": round(cum_dist, 4),
                    "elevation_m": round(raw_pts[i]["elevation"], 1),
                    "slope_pct": round(slope, 1),
                    "lat": raw_pts[i]["lat"],
                    "lon": raw_pts[i]["lon"]
                })

            self.total_distance_km = self.points[-1]["distance_km"]
            self.total_elevation_gain_m = total_ascent
            self.max_slope_pct = max_slope
            self.is_loaded = True
            return True, "OK"

        except Exception as e:
            self.is_loaded = False
            return False, str(e)

    def get_point_at_distance(self, distance_km):
        """Retorna la altitud y pendiente interpolada en un punto de la ruta."""
        if not self.is_loaded or not self.points:
            return {"elevation_m": 0.0, "slope_pct": 0.0, "progress_pct": 0.0}

        d_clamped = max(0.0, min(self.total_distance_km, distance_km))
        progress = (d_clamped / self.total_distance_km) * 100.0 if self.total_distance_km > 0 else 0.0

        # Búsqueda binaria del segmento
        low = 0
        high = len(self.points) - 1
        idx = 0
        while low <= high:
            mid = (low + high) // 2
            if self.points[mid]["distance_km"] <= d_clamped:
                idx = mid
                low = mid + 1
            else:
                high = mid - 1

        p1 = self.points[idx]
        p2 = self.points[min(idx + 1, len(self.points) - 1)]

        # Interpolación lineal si está entre dos puntos
        if p2["distance_km"] > p1["distance_km"]:
            t = (d_clamped - p1["distance_km"]) / (p2["distance_km"] - p1["distance_km"])
            ele = p1["elevation_m"] + t * (p2["elevation_m"] - p1["elevation_m"])
            slope = p1["slope_pct"] + t * (p2["slope_pct"] - p1["slope_pct"])
        else:
            ele = p1["elevation_m"]
            slope = p1["slope_pct"]

        return {
            "elevation_m": round(ele, 1),
            "slope_pct": round(slope, 1),
            "progress_pct": round(progress, 1)
        }

    def get_summary(self):
        return {
            "total_distance_km": self.total_distance_km,
            "total_elevation_gain_m": self.total_elevation_gain_m,
            "max_slope_pct": self.max_slope_pct,
            "points_count": len(self.points)
        }
