"""
Módulo de Conexión BLE para Rodillos Inteligentes (FTMS - Fitness Machine Service)
Utiliza la librería pycycling y bleak para:
1. Escanear y emparejar rodillos inteligentes (Wahoo KICKR, Tacx Neo, Elite, Magene, etc.).
2. Recibir notificaciones en tiempo real de Indoor Bike Data (0x2AD2): Potencia y Cadencia.
3. Enviar comandos al Fitness Machine Control Point (0x2AD9): Set Target Inclination (0x11).
"""

import struct
import asyncio
from bleak import BleakScanner, BleakClient
from pycycling.fitness_machine_service import FitnessMachineService

# UUIDs Oficiales del Bluetooth SIG para FTMS
FTMS_SERVICE_UUID = "00001826-0000-1000-8000-00805f9b34fb"
INDOOR_BIKE_DATA_CHAR_UUID = "00002ad2-0000-1000-8000-00805f9b34fb"
CONTROL_POINT_CHAR_UUID = "00002ad9-0000-1000-8000-00805f9b34fb"

class FtmsBleTrainerClient:
    def __init__(self):
        self.client = None
        self.is_connected = False
        self.device_name = ""
        self.ftms_service = None
        self.data_callback = None
        self._lock = asyncio.Lock()

    async def scan_for_trainers(self, timeout=5.0):
        """Escanea dispositivos Bluetooth cercanos que anuncien el servicio FTMS."""
        devices = await BleakScanner.discover(timeout=timeout)
        ftms_devices = []
        for dev in devices:
            uuids = dev.metadata.get("uuids", [])
            # Comprobar si anuncia FTMS (1826)
            if any("1826" in u.lower() for u in uuids) or any(k in (dev.name or "").lower() for k in ["kickr", "tacx", "suito", "direto", "flux", "magene", "thinkrider", "trainer", "ftms"]):
                ftms_devices.append(dev)
        return ftms_devices

    async def connect_and_subscribe(self, on_data_callback):
        """Busca el rodillo más cercano, conecta GATT y suscribe notificaciones."""
        async with self._lock:
            try:
                trainers = await self.scan_for_trainers(timeout=6.0)
                if not trainers:
                    return False, "No se encontró ningún rodillo inteligente BLE FTMS cercano."

                target_device = trainers[0]
                self.device_name = target_device.name or "Rodillo FTMS"

                self.client = BleakClient(target_device.address)
                await self.client.connect()

                if not self.client.is_connected:
                    return False, f"Fallo al conectar con {self.device_name}."

                self.data_callback = on_data_callback

                # Usar pycycling para parsear Indoor Bike Data
                self.ftms_service = FitnessMachineService(self.client)
                self.ftms_service.set_indoor_bike_data_handler(self._handle_indoor_bike_data)
                await self.ftms_service.enable_indoor_bike_data_notify()

                # Solicitar control del rodillo (Opcode 0x00: Request Control)
                await self._request_control()

                self.is_connected = True
                return True, self.device_name

            except Exception as e:
                self.is_connected = False
                return False, str(e)

    def _handle_indoor_bike_data(self, data):
        """Callback invocado por pycycling cuando llegan nuevos datos del rodillo."""
        # pycycling decodifica automáticamente:
        # data.instantaneous_power (W)
        # data.instantaneous_cadence (RPM)
        # data.instantaneous_speed (km/h)
        power_w = getattr(data, "instantaneous_power", 0) or 0
        cadence_rpm = getattr(data, "instantaneous_cadence", 0) or 0
        speed_raw = getattr(data, "instantaneous_speed", 0.0) or 0.0

        if self.data_callback:
            self.data_callback(power_w, cadence_rpm, speed_raw)

    async def _request_control(self):
        """Envía el comando FTMS 'Request Control' (Opcode 0x00) al rodillo."""
        try:
            # Opcode 0x00: Request Control
            payload = bytearray([0x00])
            await self.client.write_gatt_char(CONTROL_POINT_CHAR_UUID, payload, response=True)
        except Exception:
            # Algunos rodillos aceptan comandos directamente sin request control
            pass

    async def set_target_inclination(self, inclination_pct):
        """
        Envía comando de simulación de pendiente al rodillo (Opcode 0x11: Set Target Inclination).
        Parámetro: SINT16 en unidades de 0.1% (ej: 5.5% = 55, -3.0% = -30).
        """
        if not self.is_connected or not self.client:
            return False

        try:
            # Limitar pendiente entre -10% y +20%
            clamped = max(-10.0, min(20.0, float(inclination_pct)))
            grade_units = int(round(clamped * 10))

            # Opcode 0x11 (Set Target Inclination) + sint16 little-endian
            payload = bytearray([0x11]) + bytearray(struct.pack("<h", grade_units))
            await self.client.write_gatt_char(CONTROL_POINT_CHAR_UUID, payload, response=True)
            return True
        except Exception as e:
            print(f"[BLE FTMS] Error enviando pendiente: {e}")
            return False

    async def disconnect(self):
        """Desconecta limpiamente el cliente GATT."""
        async with self._lock:
            if self.client and self.client.is_connected:
                try:
                    await self.ftms_service.disable_indoor_bike_data_notify()
                except Exception:
                    pass
                await self.client.disconnect()
            self.is_connected = False
            self.client = None
