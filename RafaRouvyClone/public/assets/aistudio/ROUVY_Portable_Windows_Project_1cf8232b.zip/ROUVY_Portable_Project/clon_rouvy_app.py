"""
================================================================================
ROUVY SIMULATOR - CLON PROFESIONAL EN PYTHON (CustomTkinter + BLE + OpenCV + GPX)
================================================================================
Incluye:
1. Pantalla 1: Menú de inicio con escaneo de rutas locales (.mp4 / .gpx) y Bluetooth.
2. Pantalla 2: HUD flotante Rouvy (Potencia, Ritmo Cardíaco, Cadencia, Velocidad, Pendiente).
3. Conexión Bluetooth FTMS (Rodillo) y HR (Pulsómetro) en segundo plano con Bleak.
4. Reproductor OpenCV sincronizado con la velocidad virtual y pausa automática.
5. Cálculo de pendiente del terreno mediante interpolación GPX y física ciclista.
6. Controles manuales con flechas de teclado (Arriba/Abajo) para subir/bajar Watts.
================================================================================
"""

import tkinter as tk
import customtkinter as ctk
import cv2
from PIL import Image, ImageTk
import gpxpy
import math
import os
import asyncio
import threading
from bleak import BleakScanner, BleakClient
from pycycling.fitness_machine_service import FitnessMachineService

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

# UUID Estándar de Bluetooth SIG para Frecuencia Cardíaca
HR_MEASUREMENT_UUID = "00002a37-0000-1000-8000-00805f9b34fb"

class ClonRouvyApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        self.title("ROUVY - Clon Profesional")
        self.after(0, lambda: self.state('zoomed')) 
        self.minsize(1000, 700)
        
        # --- Variables de Telemetría y Control ---
        self.watts = 0           
        self.pendiente = 0.0     
        self.velocidad = 0.0     
        self.distancia_km = 0.0  
        self.cadencia = 0        
        self.pulso = 0           
        
        self.video_path = ""
        self.gpx_path = ""
        self.video_path_manual = ""
        self.gpx_path_manual = ""
        self.cap = None
        self.fps_video = 30.0
        self.puntos_gpx = []
        self.distancia_total_gpx = 0.0
        self.velocidad_referencia = 25.0  # km/h a la que se grabó el video
        
        # --- Parámetros de Entrenamiento por Intervalos (Modo ERG) ---
        self.workout_activo = False
        self.workout_iniciado_por_pedaleo = False
        self.intervalos = []
        self.indice_intervalo = 0
        self.tiempo_en_intervalo = 0.0
        self.vatios_objetivo_erg = 0
        self.workout_nombre = ""
        
        # Parámetros físicos (Ciclista + Bicicleta)
        self.peso_ciclista_kg = 75.0
        self.peso_bici_kg = 8.5
        self.peso_total_kg = 83.5  # 75 kg ciclista + 8.5 kg bicicleta
        self.cda = 0.32            # Coeficiente aerodinámico x Área frontal (m^2)
        self.crr = 0.004           # Resistencia a la rodadura
        self.rho = 1.225           # Densidad del aire (kg/m^3)
        
        # Estado de ejecución y Sincronización al Pedalear
        self.simulador_activo = False
        self.ha_iniciado_pedaleo_ruta = False  # Solo arranca el video y distancia al detectar pedaleo
        self.img_tk_actual = None
        self.imagen_fondo_rouvy = "assets/imagen_rouvy_9ae99114.png"
        
        # Perfil de Rodillo Inteligente (Wahoo / Tacx / Elite)
        self.perfil_rodillo = "Wahoo KICKR v5/v6"
        self.tiempo_suavizado_pendiente = 1.5   # Segundos de media móvil para pendiente GPX
        self.tasa_rampa_resistencia = 0.8       # Segundos de rampa FTMS para suavizar transiciones
        self.latencia_freno_ms = 120            # Anticipación de pendiente por latencia de frenado
        self.rampa_pendiente_actual = 0.0
        
        # Hilos para procesos asíncronos de Bluetooth
        self.loop = asyncio.new_event_loop()
        self.bt_thread = threading.Thread(target=self.start_async_loop, daemon=True)
        self.bt_thread.start()
        
        # Protocolo de salida limpia
        self.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        self.mostrar_pantalla_menu()

    def start_async_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    # =========================================================================
    # PANTALLA 1: MENÚ DE INICIO (Conexiones, Rutas y Modo Intervalos)
    # =========================================================================
    def mostrar_pantalla_menu(self):
        self.simulador_activo = False
        self.frame_menu = ctk.CTkFrame(self, fg_color="#0a0a0c")
        self.frame_menu.pack(fill="both", expand=True)
        
        # Cabecera de Inicio con imagen oficial Rouvy
        lbl_titulo = ctk.CTkLabel(
            self.frame_menu, 
            text="ROUVY SIMULATOR", 
            font=("Arial", 36, "bold"), 
            text_color="#FF3B30"
        )
        lbl_titulo.pack(pady=(25, 5))

        lbl_sub = ctk.CTkLabel(
            self.frame_menu,
            text="Simulador Virtual de Ciclismo con BLE FTMS y Modo ERG",
            font=("Arial", 13),
            text_color="#8E8E93"
        )
        lbl_sub.pack(pady=(0, 20))
        
        # Panel de Conexiones Bluetooth
        frame_conexiones = ctk.CTkFrame(self.frame_menu, fg_color="#141416")
        frame_conexiones.pack(pady=5, padx=40, fill="x")
        
        self.btn_menu_bt = ctk.CTkButton(
            frame_conexiones, 
            text="🔗 ENLAZAR RODILLO (FTMS)", 
            command=self.iniciar_busqueda_rodillo, 
            fg_color="#2c2c2e", 
            hover_color="#34C759", 
            font=("Arial", 13, "bold"), 
            height=42
        )
        self.btn_menu_bt.pack(side="left", expand=True, padx=15, pady=12)
        
        self.btn_menu_hr = ctk.CTkButton(
            frame_conexiones, 
            text="❤️ ENLAZAR PULSÓMETRO (HRM)", 
            command=self.iniciar_busqueda_pulsometro, 
            fg_color="#2c2c2e", 
            hover_color="#FF3B30", 
            font=("Arial", 12, "bold"), 
            height=42
        )
        self.btn_menu_hr.pack(side="left", expand=True, padx=10, pady=12)

        self.btn_menu_fisica = ctk.CTkButton(
            frame_conexiones, 
            text=f"⚙️ FÍSICA (CdA: {self.cda} | {self.peso_total_kg:.1f}kg)", 
            command=self.abrir_dialogo_fisica, 
            fg_color="#2c2c2e", 
            hover_color="#0284C7", 
            font=("Arial", 12, "bold"), 
            height=42
        )
        self.btn_menu_fisica.pack(side="left", expand=True, padx=10, pady=12)

        # Panel de Entrenamiento por Intervalos (Modo ERG)
        frame_workout = ctk.CTkFrame(self.frame_menu, fg_color="#18181b")
        frame_workout.pack(pady=10, padx=40, fill="x")

        lbl_w_title = ctk.CTkLabel(
            frame_workout,
            text="🎯 ENTRENAMIENTO POR INTERVALOS (MODO ERG):",
            font=("Arial", 13, "bold"),
            text_color="#F59E0B"
        )
        lbl_w_title.pack(side="left", padx=20, pady=10)

        self.btn_cargar_json = ctk.CTkButton(
            frame_workout,
            text="📁 Cargar Entrenamiento (.JSON)",
            command=self.cargar_archivo_workout_json,
            fg_color="#D97706",
            hover_color="#B45309",
            font=("Arial", 12, "bold"),
            height=36
        )
        self.btn_cargar_json.pack(side="left", padx=10, pady=10)

        self.btn_preset_vo2 = ctk.CTkButton(
            frame_workout,
            text="⚡ Cargar VO2 Max 4x4",
            command=self.cargar_preset_vo2max,
            fg_color="#3F3F46",
            hover_color="#52525B",
            font=("Arial", 12),
            height=36
        )
        self.btn_preset_vo2.pack(side="left", padx=10, pady=10)

        self.lbl_workout_info = ctk.CTkLabel(
            frame_workout,
            text="Ningún intervalo activo (Modo Pendiente GPX)",
            font=("Arial", 11),
            text_color="#9CA3AF"
        )
        self.lbl_workout_info.pack(side="right", padx=20)
        
        # --- SECCIÓN 1: CARGA DIRECTA DE ARCHIVOS (Desde cualquier carpeta o Pendrive) ---
        frame_archivos = ctk.CTkFrame(self.frame_menu, fg_color="#18181b")
        frame_archivos.pack(pady=8, padx=40, fill="x")

        lbl_arch_title = ctk.CTkLabel(
            frame_archivos,
            text="📁 CARGAR VIDEO (.MP4) Y RUTA (.GPX) DESDE CUALQUIER CARPETA:",
            font=("Arial", 12, "bold"),
            text_color="#38BDF8"
        )
        lbl_arch_title.pack(anchor="w", padx=20, pady=(10, 6))

        frame_arch_btns = ctk.CTkFrame(frame_archivos, fg_color="transparent")
        frame_arch_btns.pack(fill="x", padx=15, pady=(0, 6))

        self.btn_sel_video = ctk.CTkButton(
            frame_arch_btns,
            text="🎬 1. Seleccionar Video (.mp4)",
            command=self.seleccionar_video_manual,
            fg_color="#059669",
            hover_color="#047857",
            font=("Arial", 12, "bold"),
            height=36
        )
        self.btn_sel_video.pack(side="left", padx=5)

        self.btn_sel_gpx = ctk.CTkButton(
            frame_arch_btns,
            text="🗺️ 2. Seleccionar Ruta (.gpx)",
            command=self.seleccionar_gpx_manual,
            fg_color="#0284C7",
            hover_color="#0369A1",
            font=("Arial", 12, "bold"),
            height=36
        )
        self.btn_sel_gpx.pack(side="left", padx=5)

        self.btn_iniciar_manual = ctk.CTkButton(
            frame_arch_btns,
            text="🚀 INICIAR CON ESTOS ARCHIVOS",
            command=self.iniciar_con_archivos_manuales,
            fg_color="#E11D48",
            hover_color="#BE123C",
            font=("Arial", 12, "bold"),
            height=36
        )
        self.btn_iniciar_manual.pack(side="right", padx=10)

        self.lbl_archivos_info = ctk.CTkLabel(
            frame_archivos,
            text="Video: Ninguno seleccionado   |   GPX: Se buscará automáticamente con el mismo nombre",
            font=("Arial", 11),
            text_color="#9CA3AF"
        )
        self.lbl_archivos_info.pack(anchor="w", padx=20, pady=(0, 10))

        # --- SECCIÓN 2: RUTAS DETECTADAS AUTOMÁTICAMENTE (Como antes) ---
        frame_auto_header = ctk.CTkFrame(self.frame_menu, fg_color="transparent")
        frame_auto_header.pack(fill="x", padx=40, pady=(10, 4))

        lbl_subtitulo = ctk.CTkLabel(
            frame_auto_header, 
            text="📂 O seleccionar Rutas detectadas en la carpeta actual (Modo Automático):", 
            font=("Arial", 13, "bold"),
            text_color="#E5E5EA"
        )
        lbl_subtitulo.pack(side="left")

        lbl_tip = ctk.CTkLabel(
            frame_auto_header,
            text="💡 Tip: Pon tu .mp4 y .gpx con el mismo nombre en esta carpeta para verlos aquí",
            font=("Arial", 11),
            text_color="#F59E0B"
        )
        lbl_tip.pack(side="right")
        
        archivos = os.listdir(".")
        videos = [f for f in archivos if f.lower().endswith((".mp4", ".mkv", ".mov"))]
        
        frame_lista = ctk.CTkFrame(self.frame_menu, width=540, fg_color="#141416")
        frame_lista.pack(pady=5, padx=40, fill="y", expand=True)
        
        if not videos:
            lbl_no_video = ctk.CTkLabel(
                frame_lista, 
                text="❌ No se encontraron videos .mp4 en la carpeta actual.
Usa los botones verdes y azules de arriba para cargar tu video y ruta desde tu disco duro.", 
                font=("Arial", 13), 
                text_color="#FF3B30"
            )
            lbl_no_video.pack(pady=30, padx=30)
            
            # Botón para modo demo si no hay videos locales
            btn_demo = ctk.CTkButton(
                frame_lista,
                text="🚴 Probar en Modo Demo (Ruta Zion Canyon Rouvy)",
                font=("Arial", 13, "bold"),
                height=40,
                fg_color="#007AFF",
                command=lambda: self.iniciar_simulador("demo_route.mp4")
            )
            btn_demo.pack(pady=10)
        else:
            for video in videos:
                nombre_ruta = os.path.splitext(video)[0].upper().replace("_", " ")
                gpx_asociado = f"{os.path.splitext(video)[0]}.gpx"
                tiene_gpx = os.path.exists(gpx_asociado)
                texto_btn = f"🚴 {nombre_ruta} {'[+GPX]' if tiene_gpx else '[Sin GPX]'}"
                btn_ruta = ctk.CTkButton(
                    frame_lista, 
                    text=texto_btn, 
                    font=("Arial", 13, "bold"),
                    height=42,
                    width=500,
                    fg_color="#222222",
                    hover_color="#FF3B30",
                    command=lambda v=video, g=gpx_asociado if tiene_gpx else None: self.iniciar_simulador(v, g)
                )
                btn_ruta.pack(pady=6, padx=20)

    def seleccionar_video_manual(self):
        from tkinter import filedialog
        path = filedialog.askopenfilename(
            title="Seleccionar Video de Ruta (.mp4, .mkv, .mov)",
            filetypes=[("Archivos de Video", "*.mp4 *.mkv *.mov *.avi"), ("Todos los archivos", "*.*")]
        )
        if path:
            self.video_path_manual = path
            # Comprobar si existe un .gpx con el mismo nombre en la misma carpeta
            base_sin_ext = os.path.splitext(path)[0]
            if os.path.exists(f"{base_sin_ext}.gpx") and not self.gpx_path_manual:
                self.gpx_path_manual = f"{base_sin_ext}.gpx"
            self.actualizar_info_archivos_manuales()

    def seleccionar_gpx_manual(self):
        from tkinter import filedialog
        path = filedialog.askopenfilename(
            title="Seleccionar Archivo de Ruta GPX",
            filetypes=[("Archivos GPX", "*.gpx"), ("Todos los archivos", "*.*")]
        )
        if path:
            self.gpx_path_manual = path
            self.actualizar_info_archivos_manuales()

    def actualizar_info_archivos_manuales(self):
        v_name = os.path.basename(self.video_path_manual) if self.video_path_manual else "Ninguno"
        g_name = os.path.basename(self.gpx_path_manual) if self.gpx_path_manual else "Automático (.gpx con mismo nombre)"
        self.lbl_archivos_info.configure(
            text=f"🎬 Video: {v_name}   |   🗺️ GPX: {g_name}",
            text_color="#34C759" if self.video_path_manual else "#9CA3AF"
        )

    def iniciar_con_archivos_manuales(self):
        from tkinter import messagebox
        if not self.video_path_manual:
            messagebox.showwarning("Falta Video", "Por favor selecciona primero un archivo de video (.mp4) con el botón verde.")
            return
        self.iniciar_simulador(self.video_path_manual, self.gpx_path_manual)

    def abrir_dialogo_fisica(self):
        dialogo = ctk.CTkToplevel(self)
        dialogo.title("Configuración de Física y Aerodinámica")
        dialogo.geometry("460x440")
        dialogo.attributes("-topmost", True)
        dialogo.configure(fg_color="#141416")

        ctk.CTkLabel(dialogo, text="⚙️ PARÁMETROS DE VELOCIDAD VIRTUAL", font=("Arial", 16, "bold"), text_color="#38BDF8").pack(pady=15)

        # Peso Ciclista
        frame_p = ctk.CTkFrame(dialogo, fg_color="transparent")
        frame_p.pack(fill="x", padx=30, pady=6)
        ctk.CTkLabel(frame_p, text="Peso Ciclista (kg):", font=("Arial", 13)).pack(side="left")
        entry_ciclista = ctk.CTkEntry(frame_p, width=90)
        entry_ciclista.insert(0, str(getattr(self, 'peso_ciclista_kg', 75.0)))
        entry_ciclista.pack(side="right")

        # Peso Bicicleta
        frame_b = ctk.CTkFrame(dialogo, fg_color="transparent")
        frame_b.pack(fill="x", padx=30, pady=6)
        ctk.CTkLabel(frame_b, text="Peso Bicicleta (kg):", font=("Arial", 13)).pack(side="left")
        entry_bici = ctk.CTkEntry(frame_b, width=90)
        entry_bici.insert(0, str(getattr(self, 'peso_bici_kg', 8.5)))
        entry_bici.pack(side="right")

        # CdA
        frame_cda = ctk.CTkFrame(dialogo, fg_color="transparent")
        frame_cda.pack(fill="x", padx=30, pady=6)
        ctk.CTkLabel(frame_cda, text="CdA Aerodinámico (m²):", font=("Arial", 13)).pack(side="left")
        entry_cda = ctk.CTkEntry(frame_cda, width=90)
        entry_cda.insert(0, str(self.cda))
        entry_cda.pack(side="right")

        ctk.CTkLabel(
            dialogo, 
            text="Valores típicos de CdA:
• Crono / TT acople: 0.23 m²
• Agachado / Drops: 0.28 m²
• Manetas estándar: 0.32 m²
• Erguido / Tops: 0.38 m²",
            font=("Arial", 11),
            text_color="#9CA3AF",
            justify="left"
        ).pack(pady=10)

        def guardar():
            try:
                p_c = float(entry_ciclista.get())
                p_b = float(entry_bici.get())
                c_d = float(entry_cda.get())
                self.peso_ciclista_kg = p_c
                self.peso_bici_kg = p_b
                self.peso_total_kg = p_c + p_b
                self.cda = c_d
                self.btn_menu_fisica.configure(text=f"⚙️ FÍSICA (CdA: {self.cda} | {self.peso_total_kg:.1f}kg)")
                dialogo.destroy()
            except ValueError:
                pass

        ctk.CTkButton(
            dialogo, 
            text="Guardar Cambios", 
            command=guardar, 
            fg_color="#007AFF", 
            hover_color="#005ecb", 
            font=("Arial", 13, "bold"), 
            height=38
        ).pack(pady=15)

    def cargar_archivo_workout_json(self):
        from tkinter import filedialog, messagebox
        import json
        file_path = filedialog.askopenfilename(
            title="Seleccionar Archivo JSON de Intervalos",
            filetypes=[("Archivos JSON", "*.json")]
        )
        if not file_path:
            return
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.intervalos = data.get("intervals", [])
            self.workout_nombre = data.get("name", os.path.basename(file_path))
            if not self.intervalos:
                messagebox.showerror("Error", "El archivo JSON debe contener un arreglo 'intervals'.")
                return
            self.workout_activo = True
            self.indice_intervalo = 0
            self.tiempo_en_intervalo = 0.0
            self.workout_iniciado_por_pedaleo = False
            self.vatios_objetivo_erg = self.intervalos[0].get("target_watts", 150)
            self.lbl_workout_info.configure(
                text=f"✅ {self.workout_nombre} ({len(self.intervalos)} series)",
                text_color="#34C759"
            )
            messagebox.showinfo("Entrenamiento Listo", f"Entrenamiento cargado exitosamente:
{self.workout_nombre}
{len(self.intervalos)} series de potencia.

Sincronización: El cronómetro y la resistencia del rodillo se activarán automáticamente al dar la primera pedalada.")
        except Exception as e:
            messagebox.showerror("Error al leer JSON", str(e))

    def cargar_preset_vo2max(self):
        self.intervalos = [
            {"name": "Calentamiento Z1/Z2", "duration_s": 300, "target_watts": 135},
            {"name": "Rampa de Activación", "duration_s": 120, "target_watts": 200},
            {"name": "Recuperación Previa", "duration_s": 60, "target_watts": 120},
            {"name": "Serie 1 - VO2 Max", "duration_s": 240, "target_watts": 290},
            {"name": "Descanso Activo 1", "duration_s": 180, "target_watts": 135},
            {"name": "Serie 2 - VO2 Max", "duration_s": 240, "target_watts": 290},
            {"name": "Descanso Activo 2", "duration_s": 180, "target_watts": 135},
            {"name": "Serie 3 - VO2 Max", "duration_s": 240, "target_watts": 290},
            {"name": "Descanso Activo 3", "duration_s": 180, "target_watts": 135},
            {"name": "Serie 4 - VO2 Max", "duration_s": 240, "target_watts": 295},
            {"name": "Enfriamiento", "duration_s": 300, "target_watts": 110}
        ]
        self.workout_nombre = "VO2 Max 4x4 (Rouvy Pro)"
        self.workout_activo = True
        self.indice_intervalo = 0
        self.tiempo_en_intervalo = 0.0
        self.workout_iniciado_por_pedaleo = False
        self.vatios_objetivo_erg = self.intervalos[0]["target_watts"]
        self.lbl_workout_info.configure(
            text=f"✅ VO2 Max 4x4 ({len(self.intervalos)} series)",
            text_color="#34C759"
        )

    # =========================================================================
    # PANTALLA 2: INTERFAZ EN RUTA (HUD Flotante Rouvy)
    # =========================================================================
    def iniciar_simulador(self, video_seleccionado, gpx_seleccionado=None):
        self.video_path = video_seleccionado
        base_name = os.path.splitext(os.path.basename(video_seleccionado))[0]
        if gpx_seleccionado and os.path.exists(gpx_seleccionado):
            self.gpx_path = gpx_seleccionado
        else:
            base_dir = os.path.dirname(video_seleccionado)
            posible_gpx = os.path.join(base_dir, f"{base_name}.gpx") if base_dir else f"{base_name}.gpx"
            self.gpx_path = posible_gpx if os.path.exists(posible_gpx) else f"{base_name}.gpx"
        
        if hasattr(self, 'frame_menu') and self.frame_menu.winfo_exists():
            self.frame_menu.destroy()
            
        self.cargar_video()
        self.cargar_gpx()
        self.simulador_activo = True
        
        self.frame_simulador = tk.Frame(self, bg="black")
        self.frame_simulador.pack(fill="both", expand=True)
        
        # Capa de Video o Imagen de Fondo Rouvy
        self.lbl_video = tk.Label(self.frame_simulador, bg="black")
        self.lbl_video.place(x=0, y=0, relwidth=1, relheight=1)

        # --- HUD SUPERIOR CENTRO: PANEL ERG WORKOUT (Si hay entrenamiento) ---
        if self.workout_activo and self.intervalos:
            self.hud_workout = tk.Frame(self.frame_simulador, bg="#121212", bd=1, relief="ridge")
            self.hud_workout.place(relx=0.5, y=20, anchor="n", width=460, height=85)

            self.lbl_w_nombre = tk.Label(
                self.hud_workout, 
                text=f"SERIE 1/{len(self.intervalos)}: {self.intervalos[0]['name'].upper()}",
                font=("Arial", 11, "bold"),
                fg="#F59E0B",
                bg="#121212"
            )
            self.lbl_w_nombre.pack(pady=(4, 0))

            self.lbl_w_tiempo = tk.Label(
                self.hud_workout,
                text="05:00",
                font=("Arial", 24, "bold"),
                fg="#FFFFFF",
                bg="#121212"
            )
            self.lbl_w_tiempo.pack()

            self.lbl_w_status = tk.Label(
                self.hud_workout,
                text=f"🎯 OBJETIVO ERG: {self.vatios_objetivo_erg} W · Empieza a pedalear...",
                font=("Arial", 9, "bold"),
                fg="#38BDF8",
                bg="#121212"
            )
            self.lbl_w_status.pack(pady=(0, 4))
        
        # --- HUD SUPERIOR IZQUIERDO: RENDIMIENTO ---
        self.hud_izquierda = tk.Frame(self.frame_simulador, bg="#121212", bd=1, relief="ridge")
        self.hud_izquierda.place(x=25, y=25, width=220, height=210)
        
        self.lbl_watts = tk.Label(self.hud_izquierda, text="0 W", font=("Arial", 38, "bold"), fg="#FFFFFF", bg="#121212")
        self.lbl_watts.pack(pady=(15, 0))
        tk.Label(self.hud_izquierda, text="POTENCIA", font=("Arial", 9, "bold"), fg="#FF3B30", bg="#121212").pack()
        
        self.lbl_pulso = tk.Label(self.hud_izquierda, text="-- bpm", font=("Arial", 26, "bold"), fg="#FF2D55", bg="#121212")
        self.lbl_pulso.pack(pady=(12, 0))
        tk.Label(self.hud_izquierda, text="RITMO CARDÍACO", font=("Arial", 8, "bold"), fg="#8E8E93", bg="#121212").pack()
        
        self.lbl_cadencia = tk.Label(self.hud_izquierda, text="0 rpm", font=("Arial", 14, "bold"), fg="#00A2FF", bg="#121212")
        self.lbl_cadencia.pack(pady=(10, 5))

        # --- HUD SUPERIOR DERECHO: ENTORNO ---
        self.hud_derecha = tk.Frame(self.frame_simulador, bg="#121212", bd=1, relief="ridge")
        self.hud_derecha.place(relx=1.0, x=-225, y=25, width=200, height=140)
        
        self.lbl_vel = tk.Label(self.hud_derecha, text="0.0 km/h", font=("Arial", 22, "bold"), fg="#34C759", bg="#121212")
        self.lbl_vel.pack(pady=(16, 0))
        tk.Label(self.hud_derecha, text="VELOCIDAD VIRTUAL", font=("Arial", 8, "bold"), fg="#8E8E93", bg="#121212").pack()
        
        self.lbl_pendiente = tk.Label(self.hud_derecha, text="0.0 %", font=("Arial", 30, "bold"), fg="#FFCC00", bg="#121212")
        self.lbl_pendiente.pack(pady=(6, 0))
        
        # --- HUD INFERIOR: TRACKING ---
        self.hud_inferior = tk.Frame(self.frame_simulador, bg="#121212", bd=1, relief="ridge")
        self.hud_inferior.place(relx=0.05, rely=0.88, relwidth=0.9, height=55)
        
        self.lbl_distancia = tk.Label(self.hud_inferior, text="0.00 km", font=("Arial", 16, "bold"), fg="#FFFFFF", bg="#121212")
        self.lbl_distancia.pack(side="left", padx=25)
        
        tk.Label(self.hud_inferior, text=f"LIVE RUTA: {base_name.upper()}", font=("Arial", 11, "bold"), fg="#8E8E93", bg="#121212").pack(side="right", padx=25)

        # Botones Superiores: Cambiar Archivos y Salir
        frame_top_btns = tk.Frame(self.frame_simulador, bg="black")
        frame_top_btns.place(relx=0.98, y=25, anchor="ne")

        btn_cambiar = tk.Button(
            frame_top_btns,
            text="📁 Cambiar Video/GPX",
            command=self.volver_al_menu,
            bg="#1E293B",
            fg="#38BDF8",
            font=("Arial", 9, "bold"),
            relief="flat",
            padx=8,
            pady=4
        )
        btn_cambiar.pack(side="left", padx=4)

        btn_volver = tk.Button(
            frame_top_btns, 
            text="✕ Salir", 
            command=self.volver_al_menu, 
            bg="#2c2c2e", 
            fg="#FFFFFF", 
            font=("Arial", 9, "bold"),
            relief="flat",
            padx=10,
            pady=4
        )
        btn_volver.pack(side="left", padx=4)

        # Controles manuales de respaldo por teclado
        self.bind("<Up>", self.subir_watts_teclado)
        self.bind("<Down>", self.bajar_watts_teclado)
        
        # Iniciar bucles de física y video
        self.actualizar_fisica()
        self.actualizar_video()

    def volver_al_menu(self):
        self.simulador_activo = False
        if self.cap:
            self.cap.release()
            self.cap = None
        if hasattr(self, 'frame_simulador') and self.frame_simulador.winfo_exists():
            self.frame_simulador.destroy()
        self.mostrar_pantalla_menu()

    # =========================================================================
    # REPRODUCCIÓN Y SINCRONIZACIÓN DINÁMICA DE VIDEO (OpenCV)
    # =========================================================================
    def cargar_video(self):
        if os.path.exists(self.video_path):
            self.cap = cv2.VideoCapture(self.video_path)
            fps = self.cap.get(cv2.CAP_PROP_FPS)
            self.fps_video = fps if fps and fps > 0 else 30.0
        else:
            self.cap = None
            self.fps_video = 30.0

    def actualizar_video(self):
        if not self.simulador_activo:
            return

        # Si el ciclista se detiene (velocidad <= 0.5 km/h), el video se pausa
        if self.velocidad <= 0.5:
            # Reintentar en 100ms sin avanzar el fotograma
            self.after(100, self.actualizar_video)
            return

        if self.cap and self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                # Al llegar al final de la ruta, reiniciar video en bucle
                self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                ret, frame = self.cap.read()

            if ret:
                # Obtener dimensiones de la ventana
                win_w = max(400, self.lbl_video.winfo_width())
                win_h = max(300, self.lbl_video.winfo_height())

                # Redimensionar y convertir de BGR a RGB
                frame_resized = cv2.resize(frame, (win_w, win_h))
                frame_rgb = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2RGB)
                
                img_pil = Image.fromarray(frame_rgb)
                self.img_tk_actual = ImageTk.PhotoImage(image=img_pil)
                self.lbl_video.configure(image=self.img_tk_actual)

        # Ajuste dinámico de velocidad de reproducción (playback speed)
        # Ratio = velocidad actual / velocidad de grabación de referencia
        ratio = max(0.1, min(3.0, self.velocidad / self.velocidad_referencia))
        demora_ms = int(max(10, min(200, (1000.0 / self.fps_video) / ratio)))

        self.after(demora_ms, self.actualizar_video)

    # =========================================================================
    # MOTOR DE FÍSICA Y PROCESAMIENTO GPX
    # =========================================================================
    def cargar_gpx(self):
        self.puntos_gpx = []
        self.distancia_total_gpx = 0.0
        
        if not os.path.exists(self.gpx_path):
            # Perfil sintético por defecto si no hay archivo GPX
            self.distancia_total_gpx = 10.0
            return

        try:
            with open(self.gpx_path, "r", encoding="utf-8") as f:
                gpx = gpxpy.parse(f)

            raw = []
            for track in gpx.tracks:
                for seg in track.segments:
                    for pt in seg.points:
                        raw.append((pt.latitude, pt.longitude, pt.elevation or 0.0))

            cum_dist = 0.0
            for i in range(len(raw)):
                if i > 0:
                    d = self.haversine_km(raw[i-1][0], raw[i-1][1], raw[i][0], raw[i][1])
                    cum_dist += d

                # Cálculo de pendiente con ventana de suavizado
                win = min(3, min(i, len(raw) - 1 - i))
                slope = 0.0
                if win > 0:
                    p1 = raw[i - win]
                    p2 = raw[i + win]
                    d_win = self.haversine_km(p1[0], p1[1], p2[0], p2[1])
                    if d_win > 0.005:
                        slope = ((p2[2] - p1[2]) / (d_win * 1000.0)) * 100.0
                        slope = max(-20.0, min(25.0, slope))

                self.puntos_gpx.append({
                    "dist_km": cum_dist,
                    "ele_m": raw[i][2],
                    "slope_pct": slope
                })

            if self.puntos_gpx:
                self.distancia_total_gpx = self.puntos_gpx[-1]["dist_km"]
        except Exception as e:
            print(f"[GPX] Error al leer ruta: {e}")

    @staticmethod
    def haversine_km(lat1, lon1, lat2, lon2):
        r = 6371.0
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = (math.sin(dlat / 2)**2 +
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
             math.sin(dlon / 2)**2)
        return r * 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))

    def obtener_pendiente_en_distancia(self, distancia_km):
        if not self.puntos_gpx:
            # Perfil ondulado sinusoidal si no hay GPX cargado
            return 4.0 * math.sin(distancia_km * 1.5)
            
        d = max(0.0, min(self.distancia_total_gpx, distancia_km))
        for i in range(len(self.puntos_gpx) - 1):
            if d >= self.puntos_gpx[i]["dist_km"] and d <= self.puntos_gpx[i+1]["dist_km"]:
                return self.puntos_gpx[i]["slope_pct"]
        return self.puntos_gpx[-1]["slope_pct"] if self.puntos_gpx else 0.0

    def calcular_velocidad_virtual(self, watts, pendiente_pct):
        """
        Resuelve la ecuación de dinámica ciclista (Martin et al.):
        P_legs * 0.97 = P_aero + P_rolling + P_gravity
        """
        if watts <= 0 and pendiente_pct >= 0:
            return 0.0

        grade = pendiente_pct / 100.0
        theta = math.atan(grade)
        g = 9.80665
        effective_power = max(0.0, float(watts)) * 0.97

        A = 0.5 * self.rho * self.cda
        B = self.peso_total_kg * g * (math.sin(theta) + self.crr * math.cos(theta))

        # En bajadas sin pedalear (B < 0), velocidad terminal
        if effective_power <= 0.0 and B < 0:
            return math.sqrt(-B / A) * 3.6

        # Newton-Raphson para resolver A*v^3 + B*v - P = 0
        v = max(0.1, self.velocidad / 3.6)
        for _ in range(15):
            f = A * (v**3) + B * v - effective_power
            f_prime = 3.0 * A * (v**2) + B
            if abs(f_prime) < 1e-6:
                break
            v_next = v - f / f_prime
            if abs(v_next - v) < 1e-4:
                v = v_next
                break
            v = max(0.0, v_next)

        return max(0.0, v * 3.6)

    def actualizar_fisica(self):
        if not self.simulador_activo:
            return

        dt = 0.1  # 100 ms

        # 0. Sincronización al pedalear: La ruta y video solo inician cuando se empieza a pedalear
        if not self.ha_iniciado_pedaleo_ruta:
            if self.watts > 10 or self.cadencia > 0:
                self.ha_iniciado_pedaleo_ruta = True
            else:
                self.velocidad = 0.0
                self.lbl_watts.configure(text=f"{int(self.watts)} W")
                self.lbl_cadencia.configure(text=f"{int(self.cadencia)} rpm")
                self.lbl_vel.configure(text="0.0 km/h")
                self.lbl_distancia.configure(text="0.00 km · LISTO (PEDALEA)")
                self.after(100, self.actualizar_fisica)
                return

        # 1. Obtener pendiente actual según distancia recorrida y suavizado de rodillo
        self.pendiente = round(self.obtener_pendiente_en_distancia(self.distancia_km), 1)

        # 2. Manejo de Entrenamiento por Intervalos (Modo ERG con Sincronización al Pedalear)
        if self.workout_activo and self.intervalos:
            # Sincronización: Se activa únicamente cuando el ciclista empieza a pedalear
            if self.velocidad > 0.5 or self.watts > 15 or self.cadencia > 10:
                self.workout_iniciado_por_pedaleo = True

            actual_it = self.intervalos[self.indice_intervalo]
            self.vatios_objetivo_erg = actual_it.get("target_watts", 150)

            # Solo descuenta tiempo si el ciclista está pedaleando activamente
            if self.workout_iniciado_por_pedaleo and self.velocidad > 0.5:
                self.tiempo_en_intervalo += dt
                tiempo_restante = max(0, actual_it.get("duration_s", 60) - self.tiempo_en_intervalo)

                # Si finaliza la duración de la serie actual, avanza a la siguiente
                if self.tiempo_en_intervalo >= actual_it.get("duration_s", 60):
                    if self.indice_intervalo + 1 < len(self.intervalos):
                        self.indice_intervalo += 1
                        self.tiempo_en_intervalo = 0.0
                        actual_it = self.intervalos[self.indice_intervalo]
                        self.vatios_objetivo_erg = actual_it.get("target_watts", 150)
                    else:
                        self.workout_activo = False

                # Actualizar etiquetas del HUD de Intervalo
                if hasattr(self, 'lbl_w_nombre') and self.lbl_w_nombre.winfo_exists():
                    minutos = int(tiempo_restante // 60)
                    segundos = int(tiempo_restante % 60)
                    self.lbl_w_nombre.configure(
                        text=f"SERIE {self.indice_intervalo + 1}/{len(self.intervalos)}: {actual_it.get('name', 'SERIE').upper()}"
                    )
                    self.lbl_w_tiempo.configure(text=f"{minutos:02d}:{segundos:02d}")
                    self.lbl_w_status.configure(
                        text=f"🎯 OBJETIVO ERG: {self.vatios_objetivo_erg} W (Real: {int(self.watts)} W)",
                        fg="#10B981" if abs(self.watts - self.vatios_objetivo_erg) <= 15 else "#38BDF8"
                    )
            else:
                # Si se detiene, el cronómetro de la serie se pausa automáticamente
                if hasattr(self, 'lbl_w_status') and self.lbl_w_status.winfo_exists():
                    self.lbl_w_status.configure(
                        text=f"⏸️ EN PAUSA · Pedalea para reanudar el intervalo ({self.vatios_objetivo_erg} W)",
                        fg="#F59E0B"
                    )

        # 3. Calcular velocidad virtual
        vel_objetivo = self.calcular_velocidad_virtual(self.watts, self.pendiente)
        
        # Inercia de aceleración y desaceleración
        if self.watts <= 0 and self.pendiente >= 0:
            self.velocidad = max(0.0, self.velocidad - 0.8 * dt * 3.6)
        else:
            self.velocidad += (vel_objetivo - self.velocidad) * min(1.0, dt * 0.35)

        # 4. Avanzar distancia
        if self.velocidad > 0.1:
            self.distancia_km += (self.velocidad / 3600.0) * dt

        # 5. Actualizar etiquetas del HUD
        self.lbl_watts.configure(text=f"{int(self.watts)} W")
        self.lbl_pulso.configure(text=f"{self.pulso} bpm" if self.pulso > 0 else "-- bpm")
        self.lbl_cadencia.configure(text=f"{int(self.cadencia)} rpm")
        self.lbl_vel.configure(text=f"{self.velocidad:.1f} km/h")
        self.lbl_pendiente.configure(text=f"{self.pendiente:+.1f} %")
        self.lbl_distancia.configure(text=f"{self.distancia_km:.2f} km")

        self.after(100, self.actualizar_fisica)

    # =========================================================================
    # CONEXIÓN BLUETOOTH ASÍNCRONA (RODILLO FTMS Y PULSÓMETRO)
    # =========================================================================
    def iniciar_busqueda_rodillo(self):
        self.btn_menu_bt.configure(text="Buscando rodillo...", state="disabled", fg_color="#FFCC00")
        asyncio.run_coroutine_threadsafe(self.conectar_rodillo_async(), self.loop)

    def iniciar_busqueda_pulsometro(self):
        self.btn_menu_hr.configure(text="Buscando banda...", state="disabled", fg_color="#FFCC00")
        asyncio.run_coroutine_threadsafe(self.conectar_pulsometro_async(), self.loop)

    async def conectar_rodillo_async(self):
        try:
            devices = await BleakScanner.discover(timeout=6.0)
            address = None
            for d in devices:
                if d.name and any(k in d.name.upper() for k in ["TRAINER", "KICKR", "TACX", "SARIS", "ELITE", "WAHOO", "ZUMO", "CORE", "MAGENE", "THINKRIDER"]):
                    address = d.address
                    break

            if address:
                async with BleakClient(address) as client:
                    self.btn_menu_bt.configure(text="✅ RODILLO CONECTADO", fg_color="#34C759", state="normal")
                    ftms = FitnessMachineService(client)
                    ftms.set_indoor_bike_data_handler(self.manejador_rodillo)
                    await ftms.enable_indoor_bike_data_notify()
                    
                    while client.is_connected:
                        if self.workout_activo and self.vatios_objetivo_erg > 0:
                            # Modo ERG: Enviar Opcode 0x05 (Set Target Power) al Control Point FTMS (0x2AD9)
                            try:
                                import struct
                                payload = bytearray([0x05]) + bytearray(struct.pack("<h", int(self.vatios_objetivo_erg)))
                                await client.write_gatt_char("00002ad9-0000-1000-8000-00805f9b34fb", payload, response=True)
                            except Exception:
                                pass
                        else:
                            # Modo Simulación de Pendiente Física GPX
                            try:
                                await ftms.set_indoor_bike_simulation_parameters(
                                    wind_speed=0, 
                                    grade=float(self.pendiente), 
                                    crr=0.004, 
                                    cw=0.51
                                )
                            except Exception:
                                pass
                        await asyncio.sleep(1)
            else:
                self.btn_menu_bt.configure(text="❌ No detectado. Reintentar", state="normal", fg_color="#FF3B30")
        except Exception as e:
            print(f"[BLE Rodillo] Error: {e}")
            self.btn_menu_bt.configure(text="❌ Error Rodillo", state="normal", fg_color="#FF3B30")

    def manejador_rodillo(self, data):
        """Callback de pycycling cuando llegan nuevos datos de potencia/cadencia."""
        self.watts = getattr(data, "instantaneous_power", 0) or 0
        self.cadencia = getattr(data, "instantaneous_cadence", 0) or 0

    async def conectar_pulsometro_async(self):
        try:
            devices = await BleakScanner.discover(timeout=6.0)
            address = None
            for d in devices:
                if d.name and any(k in d.name.upper() for k in ["HRM", "HEART", "POLAR", "GARMIN", "WAHOO", "COOSPO", "TICKR"]):
                    address = d.address
                    break

            if address:
                async with BleakClient(address) as client:
                    self.btn_menu_hr.configure(text="❤️ PULSÓMETRO CONECTADO", fg_color="#FF2D55", state="normal")
                    await client.start_notify(HR_MEASUREMENT_UUID, self.manejador_pulsometro)
                    while client.is_connected:
                        await asyncio.sleep(1)
            else:
                self.btn_menu_hr.configure(text="❌ No detectado. Reintentar", state="normal", fg_color="#FF3B30")
        except Exception as e:
            print(f"[BLE Pulsómetro] Error: {e}")
            self.btn_menu_hr.configure(text="❌ Error Pulsómetro", state="normal", fg_color="#FF3B30")

    def manejador_pulsometro(self, sender, data: bytearray):
        """Decodifica la trama GATT estándar de Frecuencia Cardíaca (0x2A37)."""
        if not data or len(data) < 2:
            return
        flags = data[0]
        # Bit 0 indica formato de HR: 0 = UINT8 (1 byte), 1 = UINT16 (2 bytes)
        if flags & 0x01:
            hr = int.from_bytes(data[1:3], byteorder='little')
        else:
            hr = data[1]
        self.pulso = hr

    # =========================================================================
    # CONTROLES MANUALES POR TECLADO
    # =========================================================================
    def subir_watts_teclado(self, event=None):
        self.watts = min(1200, self.watts + 25)

    def bajar_watts_teclado(self, event=None):
        self.watts = max(0, self.watts - 25)

    def on_closing(self):
        self.simulador_activo = False
        if self.cap:
            self.cap.release()
        self.loop.call_soon_threadsafe(self.loop.stop)
        self.destroy()

if __name__ == "__main__":
    app = ClonRouvyApp()
    app.mainloop()
