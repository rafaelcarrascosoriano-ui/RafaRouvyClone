@echo off
title ROUVY Clon - Compilador a Ejecutable Portable Windows (.EXE)
color 0b
echo =======================================================================
echo              ROUVY CLON - CREADOR DE EJECUTABLE PORTABLE
echo =======================================================================
echo.

REM 1. Comprobar que Python este disponible en Windows
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python no esta en el PATH del sistema.
    echo Por favor instala Python 3.10 o 3.11 desde https://www.python.org/
    echo Asegurate de marcar la casilla "Add Python to PATH".
    pause
    exit /b
)

REM 2. Crear entorno virtual aislado
if not exist "build_venv" (
    echo [1/4] Creando entorno virtual aislado...
    python -m venv build_venv
)

echo [2/4] Instalando librerias necesarias...
call build_venv\Scripts\activate
pip install --upgrade pip --quiet
pip install pyinstaller customtkinter opencv-python pillow gpxpy bleak pycycling --quiet

echo.
echo [3/4] Compilando clon_rouvy_app.py a modo portable (sin ventana de consola negra)...
pyinstaller --noconfirm --onedir --windowed ^
    --name "ROUVY_Clon_Portable" ^
    --add-data "assets;assets" ^
    clon_rouvy_app.py

echo.
echo [4/4] Copiando rutas, entrenamientos y archivos a la carpeta portable...
if not exist "dist\ROUVY_Clon_Portable\routes" mkdir "dist\ROUVY_Clon_Portable\routes"
copy routes\*.gpx "dist\ROUVY_Clon_Portable\" >nul 2>&1
copy routes\*.json "dist\ROUVY_Clon_Portable\" >nul 2>&1
copy *.json "dist\ROUVY_Clon_Portable\" >nul 2>&1

echo =======================================================================
echo   LISTO! Tu ejecutable portable ha sido creado en:
echo   dist\ROUVY_Clon_Portable\ROUVY_Clon_Portable.exe
echo.
echo   Solo debes copiar la carpeta "ROUVY_Clon_Portable" a tu disco duro
echo   o pendrive USB para ejecutarlo en CUALQUIER ordenador Windows 10/11.
echo =======================================================================
pause
