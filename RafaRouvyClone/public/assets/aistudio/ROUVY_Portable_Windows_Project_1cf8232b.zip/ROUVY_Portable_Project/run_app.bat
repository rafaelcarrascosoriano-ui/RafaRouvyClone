@echo off
title PyRouvy - Lanzador de Aplicación Windows
color 0b
echo ===================================================================
echo             PyRouvy - Simulador de Ciclismo Virtual
echo ===================================================================
echo.

REM Comprobar si Python esta instalado
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python no esta instalado o no se encuentra en el PATH.
    echo Por favor descarga Python 3.11 o 3.12 desde https://www.python.org/
    pause
    exit /b
)

REM Crear entorno virtual si no existe
if not exist "venv" (
    echo [1/3] Creando entorno virtual 'venv'...
    python -m venv venv
)

echo [2/3] Activando entorno virtual e instalando dependencias...
call venv\Scripts\activate
pip install -r requirements.txt --quiet

echo.
echo [3/3] Iniciando PyRouvy Desktop...
python main.py

pause
