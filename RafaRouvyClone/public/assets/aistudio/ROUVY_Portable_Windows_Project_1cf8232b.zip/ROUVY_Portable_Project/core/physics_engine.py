"""
Motor de Dinámica Ciclista (Cycling Physics Engine)
Calcula la velocidad virtual real en función de:
- Potencia del ciclista (Watts)
- Pendiente del terreno (%)
- Peso total (Ciclista + Bicicleta)
- Coeficiente aerodinámico CdA y densidad del aire
- Coeficiente de resistencia a la rodadura (Crr)
"""

import math

class CyclingPhysicsEngine:
    def __init__(self, rider_weight_kg=75.0, bike_weight_kg=8.5, cda=0.32, crr=0.004, air_density=1.225):
        self.rider_weight_kg = rider_weight_kg
        self.bike_weight_kg = bike_weight_kg
        self.cda = cda                      # Área frontal x Coeficiente de arrastre (m^2)
        self.crr = crr                      # Resistencia a la rodadura (neumáticos de carretera)
        self.air_density = air_density      # kg/m^3 (a nivel del mar, 15°C)
        self.gravity = 9.80665              # m/s^2
        self.drivetrain_efficiency = 0.97   # 97% de eficiencia en la transmisión de la bicicleta
        self.current_speed_ms = 0.0

    @property
    def total_mass(self):
        return self.rider_weight_kg + self.bike_weight_kg

    def calculate_steady_speed(self, power_watts, slope_pct):
        """
        Calcula la velocidad en régimen estacionario resolviendo la ecuación cúbica:
        P_legs * eta = P_gravity + P_rolling + P_aero
        (0.5 * rho * CdA) * v^3 + (m * g * (sin(theta) + Crr * cos(theta))) * v - P = 0
        """
        grade = slope_pct / 100.0
        theta = math.atan(grade)
        effective_power = max(0.0, power_watts) * self.drivetrain_efficiency

        # Coeficiente cúbico aerodinámico A
        A = 0.5 * self.air_density * self.cda

        # Coeficiente lineal de pendiente y rozamiento B
        B = self.total_mass * self.gravity * (math.sin(theta) + self.crr * math.cos(theta))

        # En bajadas sin pedalear (B < 0), velocidad terminal de caída por gravedad:
        if effective_power <= 0.0 and B < 0:
            # A * v^3 + B * v = 0 -> v = sqrt(-B / A)
            return math.sqrt(-B / A)

        if effective_power <= 0.0 and B >= 0:
            return 0.0

        # Método de Newton-Raphson para hallar v (m/s)
        v = max(0.1, self.current_speed_ms)
        for _ in range(20):
            f = A * (v ** 3) + B * v - effective_power
            f_prime = 3.0 * A * (v ** 2) + B
            if abs(f_prime) < 1e-6:
                break
            v_next = v - f / f_prime
            if abs(v_next - v) < 1e-4:
                v = v_next
                break
            v = max(0.0, v_next)

        return max(0.0, v)

    def update_virtual_speed(self, power_watts, slope_pct, dt_seconds=0.1):
        """
        Actualiza la velocidad aplicando inercia y aceleración progresiva.
        Retorna la velocidad en km/h.
        """
        if power_watts <= 0 and slope_pct >= 0:
            # Frenado natural por resistencia al avance
            decel_ms2 = max(0.2, 0.4 + (slope_pct * 0.08))
            self.current_speed_ms = max(0.0, self.current_speed_ms - decel_ms2 * dt_seconds)
            return self.current_speed_ms * 3.6

        steady_speed_ms = self.calculate_steady_speed(power_watts, slope_pct)

        # Factor de convergencia inercial (la bicicleta tiene masa e inercia rotacional)
        inertia_rate = 0.3 * dt_seconds
        self.current_speed_ms += (steady_speed_ms - self.current_speed_ms) * min(1.0, inertia_rate)

        return max(0.0, self.current_speed_ms * 3.6)
