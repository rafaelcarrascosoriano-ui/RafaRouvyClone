"""
================================================================================
PyRouvy - Simulador de Ciclismo Virtual para Windows
================================================================================
Requisitos cubiertos:
1. CustomTkinter GUI con carga de video (.mp4) y ruta (.gpx) y telemetría en HUD.
2. Conexión a Rodillo Inteligente BLE FTMS usando pycycling / bleak.
3. Sincronización dinámica de reproducción de video según velocidad virtual.
4. Simulación de pendiente GPX y envío de resistencia (Target Inclination) al rodillo.
================================================================================
"""

import sys
import os
import time
import threading
import asyncio
import customtkinter as ctk
from tkinter import filedialog, messagebox

# Importar módulos del proyecto
from core.physics_engine import CyclingPhysicsEngine
from core.gpx_parser import GpxRouteParser
from core.video_sync import VlcVideoSyncPlayer
from trainer.bluetooth_ftms import FtmsBleTrainerClient

class PyRouvyApp:
    def __init__(self):
        # 1. Configurar Tema CustomTkinter
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.root = ctk.CTk()
        self.root.title("PyRouvy - Simulador de Ciclismo Virtual (BLE FTMS + GPX)")
        self.root.geometry("1280x820")
        self.root.minsize(1024, 680)

        # 2. Inicializar Subsistemas
        self.physics = CyclingPhysicsEngine(rider_weight_kg=75.0, bike_weight_kg=8.5)
        self.gpx_parser = GpxRouteParser()
        self.video_player = None  # Se inicializa tras mapear el canvas
        self.trainer_client = FtmsBleTrainerClient()

        # Estado en tiempo real
        self.is_riding = False
        self.current_power_w = 0
        self.current_cadence_rpm = 0
        self.current_speed_kmh = 0.0
        self.current_slope_pct = 0.0
        self.current_distance_km = 0.0
        self.current_elevation_m = 0.0
        self.reference_speed_kmh = 25.0  # Velocidad a la que se grabó el video

        # Control de tasa de envío FTMS (máximo 1Hz para no saturar GATT)
        self.last_ftms_grade_sent = None
        self.last_grade_send_time = 0.0

        # Construir Interfaz de Usuario
        self._build_ui()

        # Iniciar Hilo Asíncrono para Bluetooth (Bleak/pycycling requiere asyncio)
        self.ble_loop = asyncio.new_event_loop()
        self.ble_thread = threading.Thread(target=self._run_async_loop, daemon=True)
        self.ble_thread.start()

        # Iniciar bucle de física y telemetría (10 Hz = cada 100ms)
        self.root.after(100, self._telemetry_physics_tick)

        # Manejar cierre limpio
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _run_async_loop(self):
        """Ejecuta el bucle de eventos asyncio en segundo plano para Bluetooth."""
        asyncio.set_event_loop(self.ble_loop)
        self.ble_loop.run_forever()

    def _build_ui(self):
        """Construye la interfaz CustomTkinter con diseño deportivo tipo Rouvy."""
        # Barra Superior de Control
        top_bar = ctk.CTkFrame(self.root, height=54, corner_radius=0, fg_color="#111827")
        top_bar.pack(fill="x", side="top", padx=0, pady=0)

        # Título y Estado
        lbl_title = ctk.CTkLabel(top_bar, text="🚴 PyRouvy Desktop", font=ctk.CTkFont(size=18, weight="bold"), text_color="#38bdf8")
        lbl_title.pack(side="left", padx=16)

        # Botones de Carga de Archivos
        btn_load_video = ctk.CTkButton(top_bar, text="📁 Cargar Video (.mp4)", width=150, command=self._load_video_file)
        btn_load_video.pack(side="left", padx=8)

        btn_load_gpx = ctk.CTkButton(top_bar, text="🗺️ Cargar Ruta (.gpx)", width=150, command=self._load_gpx_file)
        btn_load_gpx.pack(side="left", padx=8)

        # Botón y Estado Conexión BLE
        self.btn_ble = ctk.CTkButton(top_bar, text="🔗 Conectar Rodillo FTMS", width=170, fg_color="#0284c7", hover_color="#0369a1", command=self._toggle_ble_connection)
        self.btn_ble.pack(side="right", padx=16)

        self.lbl_ble_status = ctk.CTkLabel(top_bar, text="Rodillo: Desconectado", text_color="#94a3b8")
        self.lbl_ble_status.pack(side="right", padx=12)

        # Contenedor Principal (Video + HUD flotante)
        self.content_frame = ctk.CTkFrame(self.root, fg_color="#030712", corner_radius=0)
        self.content_frame.pack(fill="both", expand=True)

        # Canvas de Video (para incrustar HWND de VLC en Windows)
        self.video_canvas = ctk.CTkCanvas(self.content_frame, bg="#000000", highlightthickness=0)
        self.video_canvas.pack(fill="both", expand=True)

        # Contenedor Flotante de Telemetría (HUD Superior)
        self._build_telemetry_hud()

        # Barra Inferior: Perfil de Elevación y Progreso
        self._build_elevation_bottom_bar()

    def _build_telemetry_hud(self):
        """Construye el HUD de telemetría estilo Rouvy."""
        hud_frame = ctk.CTkFrame(self.content_frame, fg_color="#0f172a", corner_radius=12, border_width=1, border_color="#1e293b")
        hud_frame.place(relx=0.02, rely=0.03, relwidth=0.96, height=88)

        # Cuadrícula de 4 métricas clave: Potencia, Velocidad, Cadencia, Pendiente
        # 1. POTENCIA (W)
        p_frame = ctk.CTkFrame(hud_frame, fg_color="transparent")
        p_frame.pack(side="left", expand=True, fill="both", padx=8, pady=4)
        ctk.CTkLabel(p_frame, text="POTENCIA", font=ctk.CTkFont(size=11, weight="bold"), text_color="#94a3b8").pack()
        self.lbl_power = ctk.CTkLabel(p_frame, text="0 W", font=ctk.CTkFont(size=28, weight="bold"), text_color="#38bdf8")
        self.lbl_power.pack()

        # 2. VELOCIDAD VIRTUAL (KM/H)
        s_frame = ctk.CTkFrame(hud_frame, fg_color="transparent")
        s_frame.pack(side="left", expand=True, fill="both", padx=8, pady=4)
        ctk.CTkLabel(s_frame, text="VELOCIDAD VIRTUAL", font=ctk.CTkFont(size=11, weight="bold"), text_color="#94a3b8").pack()
        self.lbl_speed = ctk.CTkLabel(s_frame, text="0.0 km/h", font=ctk.CTkFont(size=28, weight="bold"), text_color="#10b981")
        self.lbl_speed.pack()

        # 3. CADENCIA (RPM)
        c_frame = ctk.CTkFrame(hud_frame, fg_color="transparent")
        c_frame.pack(side="left", expand=True, fill="both", padx=8, pady=4)
        ctk.CTkLabel(c_frame, text="CADENCIA", font=ctk.CTkFont(size=11, weight="bold"), text_color="#94a3b8").pack()
        self.lbl_cadence = ctk.CTkLabel(c_frame, text="0 RPM", font=ctk.CTkFont(size=28, weight="bold"), text_color="#fbbf24")
        self.lbl_cadence.pack()

        # 4. PENDIENTE ACTUAL (%)
        g_frame = ctk.CTkFrame(hud_frame, fg_color="transparent")
        g_frame.pack(side="left", expand=True, fill="both", padx=8, pady=4)
        ctk.CTkLabel(g_frame, text="PENDIENTE ACTUAL", font=ctk.CTkFont(size=11, weight="bold"), text_color="#94a3b8").pack()
        self.lbl_slope = ctk.CTkLabel(g_frame, text="0.0 %", font=ctk.CTkFont(size=28, weight="bold"), text_color="#f43f5e")
        self.lbl_slope.pack()

        # 5. VELOCIDAD DE REPRODUCCIÓN (PLAYBACK RATE)
        r_frame = ctk.CTkFrame(hud_frame, fg_color="transparent")
        r_frame.pack(side="left", expand=True, fill="both", padx=8, pady=4)
        ctk.CTkLabel(r_frame, text="TASA DE VIDEO", font=ctk.CTkFont(size=11, weight="bold"), text_color="#94a3b8").pack()
        self.lbl_rate = ctk.CTkLabel(r_frame, text="0.0x (Pausa)", font=ctk.CTkFont(size=20, weight="bold"), text_color="#c084fc")
        self.lbl_rate.pack()

    def _build_elevation_bottom_bar(self):
        """Barra inferior con distancia, altitud acumulada y barra de progreso de ruta."""
        bottom_frame = ctk.CTkFrame(self.root, height=70, fg_color="#0b0f17", corner_radius=0)
        bottom_frame.pack(fill="x", side="bottom")

        info_box = ctk.CTkFrame(bottom_frame, fg_color="transparent")
        info_box.pack(fill="x", padx=16, pady=6)

        self.lbl_route_info = ctk.CTkLabel(info_box, text="Ruta: Ninguna cargada (Selecciona un archivo .gpx)", font=ctk.CTkFont(size=12), text_color="#94a3b8")
        self.lbl_route_info.pack(side="left")

        self.lbl_distance = ctk.CTkLabel(info_box, text="Distancia: 0.00 / 0.00 km | Altitud: 0 m", font=ctk.CTkFont(size=12, weight="bold"), text_color="#e2e8f0")
        self.lbl_distance.pack(side="right")

        self.progress_route = ctk.CTkProgressBar(bottom_frame, height=8, progress_color="#38bdf8")
        self.progress_route.pack(fill="x", padx=16, pady=4)
        self.progress_route.set(0.0)

    def _load_video_file(self):
        """Carga un archivo de video MP4 local y vincula el reproductor VLC."""
        file_path = filedialog.askopenfilename(title="Seleccionar Video de Ruta", filetypes=[("Archivos de Video", "*.mp4 *.mkv *.avi *.mov")])
        if not file_path:
            return

        # Inicializar VLC si aún no se ha creado
        if self.video_player is None:
            hwnd = self.video_canvas.winfo_id()
            self.video_player = VlcVideoSyncPlayer(hwnd=hwnd)

        success = self.video_player.load_media(file_path)
        if success:
            messagebox.showinfo("Video Cargado", f"Video cargado exitosamente:\n{os.path.basename(file_path)}")
            # Iniciar pausado hasta que el usuario pedalee
            self.video_player.play()
            self.video_player.set_rate(0.0)

    def _load_gpx_file(self):
        """Carga y procesa un archivo GPX de ruta."""
        file_path = filedialog.askopenfilename(title="Seleccionar Archivo GPX", filetypes=[("Archivos GPX", "*.gpx")])
        if not file_path:
            return

        success, msg = self.gpx_parser.load_file(file_path)
        if success:
            stats = self.gpx_parser.get_summary()
            self.lbl_route_info.configure(text=f"Ruta: {os.path.basename(file_path)} ({stats['total_distance_km']:.2f} km | +{stats['total_elevation_gain_m']:.0f}m)")
            messagebox.showinfo("Ruta GPX Lista", f"Ruta procesada con éxito:\nDistancia: {stats['total_distance_km']:.2f} km\nDesnivel: +{stats['total_elevation_gain_m']:.0f}m\nPendiente máx: {stats['max_slope_pct']:.1f}%")
        else:
            messagebox.showerror("Error GPX", f"No se pudo procesar el GPX:\n{msg}")

    def _toggle_ble_connection(self):
        """Conecta o desconecta el rodillo mediante BLE FTMS usando pycycling."""
        if not self.trainer_client.is_connected:
            self.btn_ble.configure(state="disabled", text="Buscando...")
            self.lbl_ble_status.configure(text="Escaneando rodillos BLE...")
            # Enviar tarea al bucle asyncio
            asyncio.run_coroutine_threadsafe(self._async_connect_trainer(), self.ble_loop)
        else:
            asyncio.run_coroutine_threadsafe(self._async_disconnect_trainer(), self.ble_loop)

    async def _async_connect_trainer(self):
        """Rutina asíncrona de conexión BLE."""
        def on_data_callback(power_w, cadence_rpm, raw_speed):
            # Callback ejecutado desde pycycling en cada notificación BLE
            self.current_power_w = power_w
            self.current_cadence_rpm = cadence_rpm

        success, name = await self.trainer_client.connect_and_subscribe(on_data_callback)
        if success:
            self.root.after(0, lambda: self._on_trainer_connected(name))
        else:
            self.root.after(0, lambda: self._on_trainer_failed(name))

    async def _async_disconnect_trainer(self):
        """Rutina asíncrona de desconexión."""
        await self.trainer_client.disconnect()
        self.root.after(0, self._on_trainer_disconnected)

    def _on_trainer_connected(self, device_name):
        self.btn_ble.configure(state="normal", text="Desconectar", fg_color="#dc2626", hover_color="#b91c1c")
        self.lbl_ble_status.configure(text=f"Conectado: {device_name}", text_color="#10b981")

    def _on_trainer_failed(self, error_msg):
        self.btn_ble.configure(state="normal", text="🔗 Conectar Rodillo FTMS", fg_color="#0284c7")
        self.lbl_ble_status.configure(text=f"Error: {error_msg}", text_color="#f87171")
        messagebox.showwarning("Fallo BLE", f"No se pudo conectar al rodillo:\n{error_msg}\n\nAsegúrate de que el rodillo esté encendido y Bluetooth activado en Windows.")

    def _on_trainer_disconnected(self):
        self.btn_ble.configure(state="normal", text="🔗 Conectar Rodillo FTMS", fg_color="#0284c7")
        self.lbl_ble_status.configure(text="Rodillo: Desconectado", text_color="#94a3b8")

    def _telemetry_physics_tick(self):
        """
        Bucle de Telemetría y Física (ejecutado a 10Hz):
        1. Calcula la velocidad virtual con la potencia actual y la pendiente del terreno.
        2. Avanza la distancia virtual recorrida.
        3. Consulta el GPX para obtener la pendiente en la distancia actual.
        4. Sincroniza la velocidad de reproducción del video.
        5. Envía el comando de resistencia (Target Inclination) al rodillo físico.
        """
        dt = 0.1  # 100 ms

        # 1. Calcular pendiente del terreno actual según distancia en GPX
        if self.gpx_parser.is_loaded:
            point_stats = self.gpx_parser.get_point_at_distance(self.current_distance_km)
            self.current_slope_pct = point_stats["slope_pct"]
            self.current_elevation_m = point_stats["elevation_m"]
            progress_pct = point_stats["progress_pct"]
            self.progress_route.set(progress_pct / 100.0)
            self.lbl_distance.configure(text=f"Distancia: {self.current_distance_km:.2f} / {self.gpx_parser.total_distance_km:.2f} km | Altitud: {self.current_elevation_m:.0f} m")

        # 2. Calcular Velocidad Virtual usando el motor de física ciclista (Martin et al.)
        self.current_speed_kmh = self.physics.update_virtual_speed(
            power_watts=self.current_power_w,
            slope_pct=self.current_slope_pct,
            dt_seconds=dt
        )

        # 3. Avanzar distancia virtual
        if self.current_speed_kmh > 0.1:
            distance_delta_km = (self.current_speed_kmh / 3600.0) * dt
            self.current_distance_km += distance_delta_km

        # 4. Sincronizar Velocidad de Reproducción de Video
        playback_rate = 0.0
        if self.video_player and self.video_player.is_loaded:
            if self.current_speed_kmh < 0.5:
                # Si el ciclista se detiene, pausar video
                self.video_player.pause()
                playback_rate = 0.0
            else:
                # Ajustar tasa proporcional a la velocidad de grabación
                playback_rate = self.current_speed_kmh / self.reference_speed_kmh
                # Limitar tasa para decodificación fluida
                playback_rate = max(0.1, min(3.0, playback_rate))
                self.video_player.set_rate(playback_rate)

        # 5. Enviar comando de pendiente física al rodillo inteligente (FTMS Set Target Inclination)
        now = time.time()
        if self.trainer_client.is_connected and (now - self.last_grade_send_time >= 1.0):
            # Enviar a lo sumo 1 vez por segundo si cambia la pendiente
            if self.last_ftms_grade_sent != round(self.current_slope_pct, 1):
                self.last_ftms_grade_sent = round(self.current_slope_pct, 1)
                self.last_grade_send_time = now
                asyncio.run_coroutine_threadsafe(
                    self.trainer_client.set_target_inclination(self.current_slope_pct),
                    self.ble_loop
                )

        # 6. Actualizar HUD de Telemetría
        self.lbl_power.configure(text=f"{self.current_power_w} W")
        self.lbl_speed.configure(text=f"{self.current_speed_kmh:.1f} km/h")
        self.lbl_cadence.configure(text=f"{self.current_cadence_rpm} RPM")
        
        # Color dinámico de pendiente
        slope_color = "#10b981" if self.current_slope_pct <= 2.0 else ("#f59e0b" if self.current_slope_pct <= 7.0 else "#ef4444")
        self.lbl_slope.configure(text=f"{self.current_slope_pct:+.1f} %", text_color=slope_color)

        rate_text = "0.0x (Pausa)" if playback_rate == 0 else f"{playback_rate:.2f}x"
        self.lbl_rate.configure(text=rate_text)

        # Programar siguiente ciclo
        self.root.after(100, self._telemetry_physics_tick)

    def _on_close(self):
        """Cierre ordenado de subprocesos."""
        if self.video_player:
            self.video_player.stop()
        if self.trainer_client.is_connected:
            asyncio.run_coroutine_threadsafe(self.trainer_client.disconnect(), self.ble_loop)
        self.ble_loop.call_soon_threadsafe(self.ble_loop.stop)
        self.root.destroy()
        sys.exit(0)

if __name__ == "__main__":
    app = PyRouvyApp()
    app.root.mainloop()
