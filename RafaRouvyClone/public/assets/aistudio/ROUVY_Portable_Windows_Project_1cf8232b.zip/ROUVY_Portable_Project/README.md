# 🚴 PyRouvy - Simulador de Ciclismo Virtual para Windows

Aplicación de escritorio para Windows estilo Rouvy construida con **Python**, **CustomTkinter** y **pycycling** (Bluetooth FTMS / ANT+ FE-C).

---

## 📋 Características Principales

1. **Interfaz Gráfica Moderna (CustomTkinter)**:
   - Carga de videos locales (`.mp4`, `.mkv`, `.mov`).
   - Carga de rutas GPS (`.gpx`) con cálculo de desnivel y perfil altimétrico.
   - HUD de Telemetría en tiempo real:
     - **Velocidad Virtual (km/h)** calculada mediante física de fluidos y rozamiento.
     - **Potencia (W)** leída directamente del potenciómetro/rodillo.
     - **Cadencia (RPM)** en tiempo real.
     - **Pendiente actual (%)** del terreno.
     - **Tasa de reproducción de video** proporcional.

2. **Conexión al Rodillo (pycycling + bleak)**:
   - Compatible con rodillos inteligentes con protocolo **Bluetooth FTMS** (Wahoo KICKR, Tacx Neo/Flux, Elite Suito/Direto, Magene T300, ThinkRider, Zwift Hub, Saris H3, etc.).
   - Lee potencia y cadencia instantánea (`0x2AD2`).

3. **Sincronización Dinámica de Video**:
   - El reproductor incrustado ajusta su `playback_speed` según la velocidad virtual del ciclista.
   - Si el ciclista deja de pedalear y la velocidad cae a 0, el video **se pausa automáticamente**. Al retomar el pedaleo, el video se reanuda suavemente.

4. **Simulación de Resistencia Física (Target Inclination)**:
   - Calcula la pendiente del terreno a partir de la distancia recorrida en el GPX.
   - Envía el comando Opcode `0x11` (**Set Target Inclination**) al Fitness Machine Control Point (`0x2AD9`) del rodillo para endurecer los frenos electromagnéticos en subidas.

---

## 🚀 Requisitos e Instalación en Windows

### 1. Requisitos Previos:
- **Windows 10 u 11** con Bluetooth 4.0/5.0 activado.
- **Python 3.10, 3.11 o 3.12** (marcar *"Add Python to PATH"* durante la instalación).
- **VLC Media Player (64-bit)** instalado en Windows (necesario para la librería `python-vlc`):
  - Descárgalo gratis desde [https://www.videolan.org/vlc/](https://www.videolan.org/vlc/).
  - *Importante*: La arquitectura de VLC (64-bit) debe coincidir con la de Python (64-bit).

### 2. Instalación en 1 Clic:
Simplemente haz doble clic sobre el archivo:
```cmd
run_app.bat
```

O manualmente por consola:
```bash
# 1. Crear y activar entorno virtual
python -m venv venv
venv\Scripts\activate

# 2. Instalar librerías
pip install -r requirements.txt

# 3. Ejecutar
python main.py
```

---

## 🛠️ Estructura del Proyecto

```
pyrouvy_project/
│
├── main.py                     # Punto de entrada y orquestador GUI + Física + BLE
├── requirements.txt            # Dependencias pip
├── run_app.bat                 # Script de inicio rápido para Windows
├── README.md                   # Documentación y manual
│
├── trainer/
│   └── bluetooth_ftms.py       # Controlador BLE FTMS (pycycling + bleak)
│
└── core/
    ├── physics_engine.py       # Ecuación de Martin et al. para velocidad virtual
    ├── gpx_parser.py           # Parser GPX con fórmula de Haversine y pendientes
    └── video_sync.py           # Reproductor VLC con tasa variable y auto-pausa
```
