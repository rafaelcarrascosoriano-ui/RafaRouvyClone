"""
Controlador de Video Sincronizado para Windows
Utiliza la librería python-vlc para:
1. Incrustar video directamente en la ventana de CustomTkinter mediante el handle HWND de Windows.
2. Controlar la tasa de reproducción en tiempo real (player.set_rate).
3. Pausar cuando el ciclista deja de pedalear y reanudar instantáneamente.
"""

import sys
import vlc

class VlcVideoSyncPlayer:
    def __init__(self, hwnd=None):
        self.hwnd = hwnd
        # Opciones de VLC para reproducción optimizada en tiempo real sin latencia de búfer
        vlc_args = [
            "--no-video-title-show",
            "--quiet",
            "--network-caching=300",
            "--file-caching=300"
        ]
        self.instance = vlc.Instance(vlc_args)
        self.player = self.instance.media_player_new()
        self.is_loaded = False
        self.is_paused = True
        self.current_rate = 1.0

        # Incrustar en el control de ventana en Windows (HWND)
        if self.hwnd:
            if sys.platform == "win32":
                self.player.set_hwnd(self.hwnd)
            elif sys.platform.startswith("linux"):
                self.player.set_xwindow(self.hwnd)

    def load_media(self, file_path):
        """Carga un archivo multimedia local."""
        try:
            media = self.instance.media_new(file_path)
            self.player.set_media(media)
            self.is_loaded = True
            return True
        except Exception as e:
            print(f"[VLC] Error cargando video: {e}")
            return False

    def play(self):
        """Inicia o reanuda la reproducción."""
        if not self.is_loaded:
            return
        self.player.play()
        self.is_paused = False

    def pause(self):
        """Pausa el video."""
        if not self.is_loaded or self.is_paused:
            return
        self.player.set_pause(1)
        self.is_paused = True

    def set_rate(self, rate):
        """
        Ajusta la velocidad de reproducción.
        Ejemplo: 1.0 = velocidad normal, 1.5 = 50% más rápido, 0.5 = cámara lenta.
        """
        if not self.is_loaded:
            return

        # Si la tasa es prácticamente cero, pausar
        if rate <= 0.05:
            self.pause()
            return

        # Si estaba en pausa y se recibe tasa positiva, reanudar
        if self.is_paused:
            self.player.set_pause(0)
            self.is_paused = False

        # Clamping entre 0.25x y 3.0x para evitar artefactos de audio/video en el decodificador
        clamped_rate = max(0.25, min(3.0, float(rate)))
        if abs(clamped_rate - self.current_rate) > 0.05:
            self.player.set_rate(clamped_rate)
            self.current_rate = clamped_rate

    def get_time_ms(self):
        return self.player.get_time()

    def stop(self):
        if self.player:
            self.player.stop()
